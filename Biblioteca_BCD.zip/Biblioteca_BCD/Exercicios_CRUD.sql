
SHOW DATABASES;

USE biblioteca_gi;

-- SELECT
-- 1. Liste o titulo e a descrição do livro, mas somente do livro com id = 3
SELECT
    titulo,
    descricao
FROM
    Livro
WHERE
    id_livro = 3;
    
-- ---------------------------------------------------------------------------------------
-- INSERT
-- 1. Cadastre um novo livro chamado "Python“, do autor "Eric Matthes", publicado em 24/04/2023,
-- do gênero (categoria) “técnico”, isbn-13: 1718502702, 3ª edição.

-- cadastrando o novo autor pois ele não existe no banco ainda
INSERT INTO Autor (nome, biografia)
VALUES ('Eric Matthes', 'Autor de livros técnicos sobre programação.');

-- cadastrando a nova categoria pq não existe no banco
INSERT INTO Categoria (nome)
VALUES ('Técnico');

-- cadastrandp o livro
INSERT INTO Livro (titulo, isbn, descricao, quantidade_paginas)
VALUES ('Python', '1718502702', 'Uma introdução prática e baseada em projetos à programação.', 544);

-- vinculando o livro ao autor na tabela associativa Autor_Livro
INSERT INTO Autor_Livro (id_livro, id_autor)
VALUES (
    (SELECT id_livro FROM Livro WHERE isbn = '1718502702'),
    (SELECT id_autor FROM Autor WHERE nome = 'Eric Matthes')
);

-- vinculando o livro à categoria na tabela associativa Categoria_Livro
INSERT INTO Categoria_Livro (id_livro, id_categoria)
VALUES (
    (SELECT id_livro FROM Livro WHERE isbn = '1718502702'),
    (SELECT id_categoria FROM Categoria WHERE nome = 'Técnico')
);

-- ---------------------------------------------------------------
-- UPDATE
-- 1. Atualizar o email do usuário id = 1 para teste@email.com
UPDATE Usuario
SET email = 'teste@gmail.com'
WHERE id_usuario = 1;

-- 2. Corrija o título do livro "Python" para " Curso Intensivo de Python: uma Introdução Prática e Baseada em Projetos à Programação ".
UPDATE Livro
SET titulo = 'Curso Intensivo de Python: uma Introdução Prática e Baseada em Projetos à Programação'
WHERE isbn = '1718502702';

-- 3. Marque todos os livros publicados antes de 2000 como status = inativo
-- adiciona as colunas necessárias se elas não existem
ALTER TABLE Livro ADD COLUMN status VARCHAR(20) DEFAULT 'ativo';
ALTER TABLE Livro ADD COLUMN data_publicacao DATE;

-- adiciona um livro de exemplo pro comando ter o que atualizar
INSERT INTO Livro (titulo, isbn, descricao, data_publicacao)
VALUES ('1984', '9788535914849', 'Uma distopia clássica sobre vigilância e controle.', '1949-06-08');
INSERT INTO Autor (nome) VALUES ('George Orwell');
INSERT INTO Autor_Livro (id_livro, id_autor)
VALUES (
    (SELECT id_livro FROM Livro WHERE isbn = '9788535914849'),
    (SELECT id_autor FROM Autor WHERE nome = 'George Orwell')
);


-- o YEAR é o comando que executa 
-- desliga a trava de segurança pra permitir a atualização
SET SQL_SAFE_UPDATES = 0;

-- atualizando os livros usando a função YEAR()
UPDATE Livro
SET status = 'inativo'
WHERE YEAR(data_publicacao) < 2000;

-- liga a trava de segurança de volta (boa prática)
SET SQL_SAFE_UPDATES = 1;


-- -----------------------------------------------------------------
-- DELETE 
-- 1. Delete o livro com id = 2.
-- boas praticas pra evitar erro de FK é remover as ref em outras tabelas
DELETE FROM Autor_Livro WHERE id_livro = 2;
DELETE FROM Categoria_Livro WHERE id_livro = 2;
DELETE FROM Emprestimo WHERE id_livro = 2;
DELETE FROM Livro WHERE id_livro = 2;

-- 2. Remova o usuário cujo nome é "Teste Testador". Se não houver, cadastre.
-- cadastrando o usuário pra ter certeza que ele existe antes de ser deletado
INSERT INTO Usuario (nome, email, data_cadastro, nivel_associacao)
VALUES ('Teste Testador', 'testador@email.com', CURDATE(), 'Normal');

-- removendo usuario cadastrado
DELETE FROM Usuario WHERE nome = 'Teste Testador';

-- 3. Apague todos os livros com status "danificado".
-- adicionando um livro com o status "danificado" pro comando DELETE ter efeito
INSERT INTO Livro (titulo, isbn, status)
VALUES ('Livro Danificado Exemplo', '9999999999999', 'danificado');

-- apagando as referências de livros danificados nas tabelas associativas pra evitar erros
DELETE FROM Autor_Livro WHERE id_livro IN (SELECT id_livro FROM Livro WHERE status = 'danificado');
DELETE FROM Categoria_Livro WHERE id_livro IN (SELECT id_livro FROM Livro WHERE status = 'danificado');
DELETE FROM Emprestimo
WHERE id_livro IN (SELECT id_livro FROM Livro WHERE status = 'danificado');

-- qpagar os livros da tabela principal com status 'danificado'
DELETE FROM Livro WHERE status = 'danificado';

-- 4. Delete 1 empréstimo realizados no ano de 2020. (Se não houver, insira)
-- inserirndo um empréstimo em 2020, pq não existe nenhum no banco de dados
INSERT INTO Emprestimo (id_usuario, id_livro, data_emprestimo, data_limite_devolucao)
VALUES (4, 6, '2020-05-15', '2020-06-15');

-- deletando um empréstimo de 2020
DELETE FROM Emprestimo
WHERE YEAR(data_emprestimo) = 2020
LIMIT 1; -- limit 1 garante que só um vai ser apagado

SELECT * FROM Livro;